export const TELEGRAM_COMMANDS = {
  STOCK: "/stock",
  SALES_TODAY: "/sales_today",
  SALES_WEEK: "/sales_week",
  SALES_MONTH: "/sales_month",
  TOP_PRODUCTS: "/top_products",
  HELP: "/help",
  START: "/start",
}

export const TELEGRAM_BOT_DESCRIPTION = `PharmaCare Bot - Pharmacy Management System

Commands:
${TELEGRAM_COMMANDS.STOCK} - Check low stock items
${TELEGRAM_COMMANDS.SALES_TODAY} - Today's sales report
${TELEGRAM_COMMANDS.SALES_WEEK} - Weekly sales report
${TELEGRAM_COMMANDS.SALES_MONTH} - Monthly sales report
${TELEGRAM_COMMANDS.TOP_PRODUCTS} - Top 5 selling products
${TELEGRAM_COMMANDS.HELP} - Show help message`
