"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useParams, useRouter } from "next/navigation"
import { usePharmacy } from "@/hooks/use-pharmacy"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

interface Product {
  id: string
  name: string
  sku: string
  barcode: string | null
  unit_price: number
  cost_price: number | null
  category: string | null
}

interface Stock {
  id: string
  quantity_available: number
  low_stock_threshold_fixed: number | null
  low_stock_threshold_percentage: number
}

export default function EditProductPage() {
  const { pharmacy } = usePharmacy()
  const params = useParams()
  const router = useRouter()
  const productId = params.productId as string

  const [product, setProduct] = useState<Product | null>(null)
  const [stock, setStock] = useState<Stock | null>(null)
  const [loading, setLoading] = useState(true)
  const [updating, setUpdating] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [quantityChange, setQuantityChange] = useState("")
  const [changeType, setChangeType] = useState<"manual" | "barcode" | "api">("manual")

  useEffect(() => {
    const fetchProduct = async () => {
      if (!pharmacy) return

      const supabase = createClient()
      const { data: productData } = await supabase
        .from("products")
        .select("*")
        .eq("id", productId)
        .eq("pharmacy_id", pharmacy.id)
        .single()

      const { data: stockData } = await supabase
        .from("stock")
        .select("*")
        .eq("product_id", productId)
        .eq("pharmacy_id", pharmacy.id)
        .single()

      if (productData) setProduct(productData)
      if (stockData) setStock(stockData)
      setLoading(false)
    }

    fetchProduct()
  }, [pharmacy, productId])

  const handleUpdateStock = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!stock || !quantityChange) return

    setUpdating(true)
    setError(null)

    try {
      const supabase = createClient()
      const newQuantity = stock.quantity_available + Number.parseInt(quantityChange)

      const { error: updateError } = await supabase
        .from("stock")
        .update({ quantity_available: newQuantity })
        .eq("id", stock.id)

      if (updateError) throw updateError

      // Log to stock history
      await supabase.from("stock_history").insert({
        pharmacy_id: pharmacy!.id,
        product_id: productId,
        change_type: changeType,
        quantity_change: Number.parseInt(quantityChange),
        previous_quantity: stock.quantity_available,
        new_quantity: newQuantity,
      })

      setStock({ ...stock, quantity_available: newQuantity })
      setQuantityChange("")
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setUpdating(false)
    }
  }

  if (loading) return <div className="p-8">Loading...</div>
  if (!product || !stock) return <div className="p-8">Product not found</div>

  return (
    <div className="p-8 space-y-6">
      <Link href="/dashboard/stock" className="flex items-center gap-2 text-primary hover:underline">
        <ArrowLeft className="w-4 h-4" />
        Back to Stock
      </Link>

      <div>
        <h1 className="text-3xl font-bold text-foreground">{product.name}</h1>
        <p className="text-muted-foreground mt-2">SKU: {product.sku}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Product Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-muted-foreground">Product Name</Label>
              <p className="text-lg font-semibold">{product.name}</p>
            </div>
            <div>
              <Label className="text-muted-foreground">SKU</Label>
              <p className="text-lg font-semibold">{product.sku}</p>
            </div>
            {product.barcode && (
              <div>
                <Label className="text-muted-foreground">Barcode</Label>
                <p className="text-lg font-semibold">{product.barcode}</p>
              </div>
            )}
            <div>
              <Label className="text-muted-foreground">Unit Price</Label>
              <p className="text-lg font-semibold">${product.unit_price.toFixed(2)}</p>
            </div>
            {product.cost_price && (
              <div>
                <Label className="text-muted-foreground">Cost Price</Label>
                <p className="text-lg font-semibold">${product.cost_price.toFixed(2)}</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Update Stock</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-muted-foreground">Current Quantity</Label>
              <p className="text-3xl font-bold text-primary">{stock.quantity_available}</p>
            </div>

            <form onSubmit={handleUpdateStock} className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="changeType">Change Type</Label>
                <select
                  id="changeType"
                  value={changeType}
                  onChange={(e) => setChangeType(e.target.value as any)}
                  className="px-3 py-2 border border-border rounded-lg bg-background"
                >
                  <option value="manual">Manual Entry</option>
                  <option value="barcode">Barcode Scan</option>
                  <option value="api">API Integration</option>
                </select>
              </div>

              <div className="grid gap-2">
                <Label htmlFor="quantityChange">Quantity Change</Label>
                <Input
                  id="quantityChange"
                  type="number"
                  placeholder="e.g., +10 or -5"
                  value={quantityChange}
                  onChange={(e) => setQuantityChange(e.target.value)}
                />
              </div>

              {error && <p className="text-sm text-destructive">{error}</p>}

              <Button type="submit" className="w-full" disabled={updating}>
                {updating ? "Updating..." : "Update Stock"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
