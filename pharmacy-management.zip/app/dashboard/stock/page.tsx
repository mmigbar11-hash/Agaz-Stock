"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { Plus, Search, AlertTriangle } from "lucide-react"
import { usePharmacy } from "@/hooks/use-pharmacy"

interface Product {
  id: string
  name: string
  sku: string
  barcode: string | null
  unit_price: number
  stock: {
    quantity_available: number
    low_stock_threshold_fixed: number | null
    low_stock_threshold_percentage: number
  }[]
}

export default function StockPage() {
  const { pharmacy } = usePharmacy()
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    const fetchProducts = async () => {
      if (!pharmacy) return

      const supabase = createClient()
      const { data } = await supabase
        .from("products")
        .select("id, name, sku, barcode, unit_price, stock(*)")
        .eq("pharmacy_id", pharmacy.id)
        .eq("is_active", true)

      if (data) {
        setProducts(data as Product[])
      }
      setLoading(false)
    }

    fetchProducts()
  }, [pharmacy])

  const filteredProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.barcode?.includes(searchTerm),
  )

  const isLowStock = (product: Product) => {
    if (!product.stock[0]) return false
    const threshold =
      product.stock[0].low_stock_threshold_fixed ||
      Math.ceil((product.stock[0].low_stock_threshold_percentage / 100) * 100)
    return product.stock[0].quantity_available <= threshold
  }

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Stock Management</h1>
          <p className="text-muted-foreground mt-2">Manage your pharmacy inventory</p>
        </div>
        <Link href="/dashboard/stock/add-product">
          <Button className="gap-2">
            <Plus className="w-4 h-4" />
            Add Product
          </Button>
        </Link>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Products</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by name, SKU, or barcode..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          {loading ? (
            <p className="text-muted-foreground">Loading products...</p>
          ) : filteredProducts.length === 0 ? (
            <p className="text-muted-foreground">No products found</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 font-semibold">Product Name</th>
                    <th className="text-left py-3 px-4 font-semibold">SKU</th>
                    <th className="text-left py-3 px-4 font-semibold">Quantity</th>
                    <th className="text-left py-3 px-4 font-semibold">Unit Price</th>
                    <th className="text-left py-3 px-4 font-semibold">Status</th>
                    <th className="text-left py-3 px-4 font-semibold">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredProducts.map((product) => (
                    <tr key={product.id} className="border-b border-border hover:bg-muted/50">
                      <td className="py-3 px-4">{product.name}</td>
                      <td className="py-3 px-4 text-muted-foreground">{product.sku}</td>
                      <td className="py-3 px-4">
                        <span className={isLowStock(product) ? "text-orange-500 font-semibold" : ""}>
                          {product.stock[0]?.quantity_available || 0}
                        </span>
                      </td>
                      <td className="py-3 px-4">${product.unit_price.toFixed(2)}</td>
                      <td className="py-3 px-4">
                        {isLowStock(product) ? (
                          <div className="flex items-center gap-1 text-orange-500">
                            <AlertTriangle className="w-4 h-4" />
                            Low Stock
                          </div>
                        ) : (
                          <span className="text-green-500">In Stock</span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <Link href={`/dashboard/stock/${product.id}`}>
                          <Button variant="outline" size="sm">
                            Edit
                          </Button>
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
