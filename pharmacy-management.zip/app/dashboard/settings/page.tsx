"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { usePharmacy } from "@/hooks/use-pharmacy"
import { Copy, Check } from "lucide-react"

export default function SettingsPage() {
  const { pharmacy } = usePharmacy()
  const [telegramBotToken, setTelegramBotToken] = useState("")
  const [webhookUrl, setWebhookUrl] = useState("")
  const [copied, setCopied] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  useEffect(() => {
    if (typeof window !== "undefined") {
      setWebhookUrl(`${window.location.origin}/api/telegram/webhook`)
    }
  }, [])

  const handleSetupTelegramBot = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!telegramBotToken) return

    setLoading(true)
    setError(null)
    setSuccess(null)

    try {
      // Set webhook for Telegram bot
      const response = await fetch(`https://api.telegram.org/bot${telegramBotToken}/setWebhook`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: webhookUrl,
        }),
      })

      const result = await response.json()

      if (!result.ok) {
        throw new Error(result.description || "Failed to set webhook")
      }

      setSuccess("Telegram bot webhook configured successfully!")
      setTelegramBotToken("")
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(webhookUrl)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Settings</h1>
        <p className="text-muted-foreground mt-2">Manage your pharmacy settings and integrations</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Pharmacy Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="text-muted-foreground">Pharmacy Name</Label>
            <p className="text-lg font-semibold">{pharmacy?.name}</p>
          </div>
          <div>
            <Label className="text-muted-foreground">Email</Label>
            <p className="text-lg font-semibold">{pharmacy?.email}</p>
          </div>
          <div>
            <Label className="text-muted-foreground">Subscription Plan</Label>
            <p className="text-lg font-semibold capitalize">{pharmacy?.subscription_plan}</p>
          </div>
          <div>
            <Label className="text-muted-foreground">Status</Label>
            <p className="text-lg font-semibold capitalize">{pharmacy?.subscription_status}</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Telegram Bot Integration</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Set up a Telegram bot to receive stock alerts, sales reports, and manage your pharmacy remotely.
          </p>

          <div className="space-y-4">
            <div>
              <Label htmlFor="webhookUrl">Webhook URL</Label>
              <div className="flex gap-2 mt-2">
                <Input id="webhookUrl" value={webhookUrl} readOnly className="bg-muted" />
                <Button variant="outline" size="sm" onClick={copyToClipboard}>
                  {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Copy this URL and use it when setting up your Telegram bot webhook.
              </p>
            </div>

            <form onSubmit={handleSetupTelegramBot} className="space-y-4">
              <div>
                <Label htmlFor="botToken">Telegram Bot Token</Label>
                <Input
                  id="botToken"
                  type="password"
                  placeholder="Enter your Telegram bot token"
                  value={telegramBotToken}
                  onChange={(e) => setTelegramBotToken(e.target.value)}
                  className="mt-2"
                />
                <p className="text-xs text-muted-foreground mt-2">
                  Get your bot token from{" "}
                  <a href="https://t.me/botfather" target="_blank" rel="noopener noreferrer" className="underline">
                    @BotFather
                  </a>{" "}
                  on Telegram.
                </p>
              </div>

              {error && <p className="text-sm text-destructive">{error}</p>}
              {success && <p className="text-sm text-green-500">{success}</p>}

              <Button type="submit" disabled={loading || !telegramBotToken}>
                {loading ? "Setting up..." : "Setup Telegram Bot"}
              </Button>
            </form>
          </div>

          <div className="bg-muted p-4 rounded-lg space-y-2">
            <p className="font-semibold text-sm">Available Bot Commands:</p>
            <ul className="text-sm space-y-1 text-muted-foreground">
              <li>/stock - Check low stock items</li>
              <li>/sales_today - Today's sales report</li>
              <li>/sales_week - Weekly sales report</li>
              <li>/sales_month - Monthly sales report</li>
              <li>/top_products - Top 5 selling products</li>
              <li>/help - Show help message</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
