import { createClient } from "@/lib/supabase/server"
import { DashboardMetrics } from "@/components/dashboard/metrics"
import { LowStockAlerts } from "@/components/dashboard/low-stock-alerts"
import { RecentSales } from "@/components/dashboard/recent-sales"
import { SalesChart } from "@/components/dashboard/sales-chart"

export default async function DashboardPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) return null

  // Get user's pharmacy
  const { data: userData } = await supabase.from("users").select("pharmacy_id").eq("id", user.id).single()

  if (!userData) return null

  const pharmacyId = userData.pharmacy_id

  // Get metrics
  const { data: products } = await supabase
    .from("products")
    .select("id")
    .eq("pharmacy_id", pharmacyId)
    .eq("is_active", true)

  const { data: lowStockItems } = await supabase
    .from("stock")
    .select("id, quantity_available, low_stock_threshold_fixed, low_stock_threshold_percentage")
    .eq("pharmacy_id", pharmacyId)

  const { data: todaySales } = await supabase
    .from("sales")
    .select("total_amount")
    .eq("pharmacy_id", pharmacyId)
    .gte("created_at", new Date(new Date().setHours(0, 0, 0, 0)).toISOString())

  const { data: recentSalesData } = await supabase
    .from("sales")
    .select("*, sales_items(*, products(name))")
    .eq("pharmacy_id", pharmacyId)
    .order("created_at", { ascending: false })
    .limit(5)

  const lowStockCount =
    lowStockItems?.filter((item) => {
      const threshold = item.low_stock_threshold_fixed || Math.ceil((item.low_stock_threshold_percentage / 100) * 100)
      return item.quantity_available <= threshold
    }).length || 0

  const todayRevenue = todaySales?.reduce((sum, sale) => sum + sale.total_amount, 0) || 0

  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground mt-2">Welcome to your pharmacy management system</p>
      </div>

      <DashboardMetrics
        totalProducts={products?.length || 0}
        lowStockCount={lowStockCount}
        todayRevenue={todayRevenue}
        totalSales={todaySales?.length || 0}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <SalesChart pharmacyId={pharmacyId} />
        </div>
        <div>
          <LowStockAlerts pharmacyId={pharmacyId} />
        </div>
      </div>

      <RecentSales sales={recentSalesData || []} />
    </div>
  )
}
