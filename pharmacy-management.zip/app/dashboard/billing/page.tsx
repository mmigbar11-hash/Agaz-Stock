"use client"

import { Label } from "@/components/ui/label"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { usePharmacy } from "@/hooks/use-pharmacy"
import { Check } from "lucide-react"
import { loadStripe } from "@stripe/js"

interface Plan {
  id: string
  name: string
  price: number
  description: string
  features: string[]
  popular?: boolean
}

const plans: Plan[] = [
  {
    id: "basic",
    name: "Basic",
    price: 29.99,
    description: "Perfect for small pharmacies",
    features: ["Up to 500 products", "Basic analytics", "Email support", "1 user account", "Stock management"],
  },
  {
    id: "pro",
    name: "Professional",
    price: 79.99,
    description: "For growing pharmacies",
    features: [
      "Up to 5,000 products",
      "Advanced analytics",
      "Priority support",
      "5 user accounts",
      "Stock management",
      "Telegram bot integration",
      "Sales reports",
    ],
    popular: true,
  },
  {
    id: "enterprise",
    name: "Enterprise",
    price: 199.99,
    description: "For large pharmacy chains",
    features: [
      "Unlimited products",
      "Custom analytics",
      "24/7 dedicated support",
      "Unlimited user accounts",
      "Stock management",
      "Telegram bot integration",
      "Advanced sales reports",
      "API access",
      "Custom integrations",
    ],
  },
]

export default function BillingPage() {
  const { pharmacy } = usePharmacy()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    if (params.get("success")) {
      setSuccess(true)
    }
  }, [])

  const handleSubscribe = async (planId: string) => {
    setLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/stripe/create-checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ plan: planId }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to create checkout session")
      }

      const stripe = await loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY)
      if (!stripe) throw new Error("Failed to load Stripe")

      const { error: stripeError } = await stripe.redirectToCheckout({
        sessionId: data.sessionId,
      })

      if (stripeError) {
        throw new Error(stripeError.message)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Billing & Plans</h1>
        <p className="text-muted-foreground mt-2">Manage your subscription and billing</p>
      </div>

      {success && (
        <div className="bg-green-500/10 border border-green-500 text-green-700 p-4 rounded-lg">
          Payment successful! Your subscription has been activated.
        </div>
      )}

      {pharmacy && (
        <Card>
          <CardHeader>
            <CardTitle>Current Plan</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-muted-foreground">Current Plan</Label>
              <p className="text-lg font-semibold capitalize">{pharmacy.subscription_plan}</p>
            </div>
            <div>
              <Label className="text-muted-foreground">Status</Label>
              <p className="text-lg font-semibold capitalize">{pharmacy.subscription_status}</p>
            </div>
          </CardContent>
        </Card>
      )}

      <div>
        <h2 className="text-2xl font-bold mb-6">Choose Your Plan</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans.map((plan) => (
            <Card key={plan.id} className={plan.popular ? "border-primary" : ""}>
              <CardHeader>
                {plan.popular && (
                  <div className="bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-semibold w-fit mb-2">
                    Most Popular
                  </div>
                )}
                <CardTitle>{plan.name}</CardTitle>
                <p className="text-muted-foreground text-sm">{plan.description}</p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <span className="text-4xl font-bold">${plan.price}</span>
                  <span className="text-muted-foreground">/month</span>
                </div>

                <ul className="space-y-3">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2">
                      <Check className="w-5 h-5 text-green-500" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button
                  onClick={() => handleSubscribe(plan.id)}
                  disabled={loading}
                  className={plan.popular ? "" : ""}
                  variant={plan.popular ? "default" : "outline"}
                >
                  {loading ? "Processing..." : "Subscribe Now"}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {error && (
        <div className="bg-destructive/10 border border-destructive text-destructive p-4 rounded-lg">{error}</div>
      )}
    </div>
  )
}
