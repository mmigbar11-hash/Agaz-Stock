"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useRouter } from "next/navigation"
import { usePharmacy } from "@/hooks/use-pharmacy"
import Link from "next/link"
import { ArrowLeft, Plus, Trash2 } from "lucide-react"

interface Product {
  id: string
  name: string
  sku: string
  unit_price: number
  stock: Array<{
    quantity_available: number
  }>
}

interface CartItem {
  productId: string
  productName: string
  quantity: number
  unitPrice: number
}

export default function NewSalePage() {
  const { pharmacy } = usePharmacy()
  const router = useRouter()
  const [products, setProducts] = useState<Product[]>([])
  const [cart, setCart] = useState<CartItem[]>([])
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [paymentMethod, setPaymentMethod] = useState("cash")
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedQuantity, setSelectedQuantity] = useState<{ [key: string]: number }>({})

  useEffect(() => {
    const fetchProducts = async () => {
      if (!pharmacy) return

      const supabase = createClient()
      const { data } = await supabase
        .from("products")
        .select("id, name, sku, unit_price, stock(*)")
        .eq("pharmacy_id", pharmacy.id)
        .eq("is_active", true)

      if (data) {
        setProducts(data as Product[])
      }
      setLoading(false)
    }

    fetchProducts()
  }, [pharmacy])

  const filteredProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) || p.sku.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const addToCart = (product: Product) => {
    const quantity = selectedQuantity[product.id] || 1
    const existingItem = cart.find((item) => item.productId === product.id)

    if (existingItem) {
      setCart(
        cart.map((item) => (item.productId === product.id ? { ...item, quantity: item.quantity + quantity } : item)),
      )
    } else {
      setCart([
        ...cart,
        {
          productId: product.id,
          productName: product.name,
          quantity,
          unitPrice: product.unit_price,
        },
      ])
    }

    setSelectedQuantity({ ...selectedQuantity, [product.id]: 1 })
  }

  const removeFromCart = (productId: string) => {
    setCart(cart.filter((item) => item.productId !== productId))
  }

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId)
    } else {
      setCart(cart.map((item) => (item.productId === productId ? { ...item, quantity } : item)))
    }
  }

  const totalAmount = cart.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0)

  const handleSubmitSale = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!pharmacy || cart.length === 0) return

    setSubmitting(true)
    setError(null)

    try {
      const supabase = createClient()

      // Create sale
      const { data: saleData, error: saleError } = await supabase
        .from("sales")
        .insert({
          pharmacy_id: pharmacy.id,
          total_amount: totalAmount,
          payment_method: paymentMethod,
          sale_source: "pos",
        })
        .select()
        .single()

      if (saleError) throw saleError

      // Create sale items
      const saleItems = cart.map((item) => ({
        sale_id: saleData.id,
        product_id: item.productId,
        quantity: item.quantity,
        unit_price: item.unitPrice,
        total_price: item.quantity * item.unitPrice,
      }))

      const { error: itemsError } = await supabase.from("sales_items").insert(saleItems)

      if (itemsError) throw itemsError

      // Update stock
      for (const item of cart) {
        const product = products.find((p) => p.id === item.productId)
        if (product) {
          const currentStock = product.stock[0]?.quantity_available || 0
          const newStock = currentStock - item.quantity

          await supabase
            .from("stock")
            .update({ quantity_available: newStock })
            .eq("product_id", item.productId)
            .eq("pharmacy_id", pharmacy.id)
        }
      }

      router.push("/dashboard/sales")
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="p-8 space-y-6">
      <Link href="/dashboard/sales" className="flex items-center gap-2 text-primary hover:underline">
        <ArrowLeft className="w-4 h-4" />
        Back to Sales
      </Link>

      <div>
        <h1 className="text-3xl font-bold text-foreground">New Sale</h1>
        <p className="text-muted-foreground mt-2">Create a new sales transaction</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Select Products</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input
                placeholder="Search products by name or SKU..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />

              {loading ? (
                <p className="text-muted-foreground">Loading products...</p>
              ) : filteredProducts.length === 0 ? (
                <p className="text-muted-foreground">No products found</p>
              ) : (
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {filteredProducts.map((product) => (
                    <div key={product.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                      <div className="flex-1">
                        <p className="font-medium">{product.name}</p>
                        <p className="text-sm text-muted-foreground">
                          ${product.unit_price.toFixed(2)} - Stock: {product.stock[0]?.quantity_available || 0}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Input
                          type="number"
                          min="1"
                          max={product.stock[0]?.quantity_available || 0}
                          value={selectedQuantity[product.id] || 1}
                          onChange={(e) =>
                            setSelectedQuantity({
                              ...selectedQuantity,
                              [product.id]: Number.parseInt(e.target.value) || 1,
                            })
                          }
                          className="w-16"
                        />
                        <Button size="sm" onClick={() => addToCart(product)}>
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Shopping Cart</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {cart.length === 0 ? (
                <p className="text-muted-foreground">No items in cart</p>
              ) : (
                <>
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {cart.map((item) => (
                      <div key={item.productId} className="p-3 bg-muted rounded-lg space-y-2">
                        <div className="flex items-center justify-between">
                          <p className="font-medium text-sm">{item.productName}</p>
                          <Button variant="ghost" size="sm" onClick={() => removeFromCart(item.productId)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                        <div className="flex items-center gap-2">
                          <Input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => updateCartQuantity(item.productId, Number.parseInt(e.target.value) || 1)}
                            className="w-16"
                          />
                          <p className="text-sm text-muted-foreground">
                            ${(item.quantity * item.unitPrice).toFixed(2)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="border-t border-border pt-4 space-y-3">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Subtotal:</span>
                      <span className="font-semibold">${totalAmount.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-lg font-bold">
                      <span>Total:</span>
                      <span>${totalAmount.toFixed(2)}</span>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Payment</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmitSale} className="space-y-4">
                <div className="grid gap-2">
                  <Label htmlFor="paymentMethod">Payment Method</Label>
                  <select
                    id="paymentMethod"
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="px-3 py-2 border border-border rounded-lg bg-background"
                  >
                    <option value="cash">Cash</option>
                    <option value="card">Card</option>
                    <option value="online">Online</option>
                    <option value="check">Check</option>
                  </select>
                </div>

                {error && <p className="text-sm text-destructive">{error}</p>}

                <Button type="submit" className="w-full" disabled={submitting || cart.length === 0}>
                  {submitting ? "Processing..." : "Complete Sale"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
