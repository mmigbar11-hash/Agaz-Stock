"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { Plus, Search } from "lucide-react"
import { usePharmacy } from "@/hooks/use-pharmacy"

interface Sale {
  id: string
  total_amount: number
  payment_method: string | null
  sale_source: string
  created_at: string
  sales_items: Array<{
    quantity: number
    unit_price: number
    products: {
      name: string
    }
  }>
}

export default function SalesPage() {
  const { pharmacy } = usePharmacy()
  const [sales, setSales] = useState<Sale[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterPeriod, setFilterPeriod] = useState<"today" | "week" | "month">("today")

  useEffect(() => {
    const fetchSales = async () => {
      if (!pharmacy) return

      const supabase = createClient()

      let query = supabase
        .from("sales")
        .select("*, sales_items(*, products(name))")
        .eq("pharmacy_id", pharmacy.id)
        .order("created_at", { ascending: false })

      // Filter by period
      const now = new Date()
      const startDate = new Date()

      if (filterPeriod === "today") {
        startDate.setHours(0, 0, 0, 0)
      } else if (filterPeriod === "week") {
        startDate.setDate(now.getDate() - 7)
      } else if (filterPeriod === "month") {
        startDate.setDate(now.getDate() - 30)
      }

      query = query.gte("created_at", startDate.toISOString())

      const { data } = await query

      if (data) {
        setSales(data as Sale[])
      }
      setLoading(false)
    }

    fetchSales()
  }, [pharmacy, filterPeriod])

  const filteredSales = sales.filter((s) =>
    s.sales_items.some((item) => item.products.name.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  const totalRevenue = filteredSales.reduce((sum, sale) => sum + sale.total_amount, 0)
  const topProducts = filteredSales
    .flatMap((s) => s.sales_items)
    .reduce(
      (acc, item) => {
        const existing = acc.find((p) => p.name === item.products.name)
        if (existing) {
          existing.quantity += item.quantity
          existing.revenue += item.quantity * item.unit_price
        } else {
          acc.push({
            name: item.products.name,
            quantity: item.quantity,
            revenue: item.quantity * item.unit_price,
          })
        }
        return acc
      },
      [] as Array<{ name: string; quantity: number; revenue: number }>,
    )
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 5)

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Sales Management</h1>
          <p className="text-muted-foreground mt-2">Track and analyze your sales</p>
        </div>
        <Link href="/dashboard/sales/new">
          <Button className="gap-2">
            <Plus className="w-4 h-4" />
            New Sale
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">${totalRevenue.toFixed(2)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{filteredSales.length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Average Transaction</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">
              ${filteredSales.length > 0 ? (totalRevenue / filteredSales.length).toFixed(2) : "0.00"}
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Sales Analytics</CardTitle>
            <div className="flex gap-2">
              {(["today", "week", "month"] as const).map((period) => (
                <Button
                  key={period}
                  variant={filterPeriod === period ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilterPeriod(period)}
                  className="capitalize"
                >
                  {period}
                </Button>
              ))}
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="font-semibold mb-4">Top Selling Products</h3>
            <div className="space-y-3">
              {topProducts.length === 0 ? (
                <p className="text-muted-foreground">No sales data</p>
              ) : (
                topProducts.map((product) => (
                  <div key={product.name} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div>
                      <p className="font-medium">{product.name}</p>
                      <p className="text-sm text-muted-foreground">{product.quantity} units sold</p>
                    </div>
                    <p className="font-semibold">${product.revenue.toFixed(2)}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Sales</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by product name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          {loading ? (
            <p className="text-muted-foreground">Loading sales...</p>
          ) : filteredSales.length === 0 ? (
            <p className="text-muted-foreground">No sales found</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 font-semibold">Date & Time</th>
                    <th className="text-left py-3 px-4 font-semibold">Items</th>
                    <th className="text-left py-3 px-4 font-semibold">Amount</th>
                    <th className="text-left py-3 px-4 font-semibold">Payment Method</th>
                    <th className="text-left py-3 px-4 font-semibold">Source</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredSales.map((sale) => (
                    <tr key={sale.id} className="border-b border-border hover:bg-muted/50">
                      <td className="py-3 px-4">{new Date(sale.created_at).toLocaleString()}</td>
                      <td className="py-3 px-4">{sale.sales_items.length} items</td>
                      <td className="py-3 px-4 font-semibold">${sale.total_amount.toFixed(2)}</td>
                      <td className="py-3 px-4 capitalize">{sale.payment_method || "N/A"}</td>
                      <td className="py-3 px-4 capitalize">{sale.sale_source}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
