import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"
import Stripe from "stripe"

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", {
  apiVersion: "2024-11-20",
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { plan } = body

    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get user's pharmacy
    const { data: userData } = await supabase.from("users").select("pharmacy_id").eq("id", user.id).single()

    if (!userData) {
      return NextResponse.json({ error: "Pharmacy not found" }, { status: 404 })
    }

    const { data: pharmacy } = await supabase.from("pharmacies").select("*").eq("id", userData.pharmacy_id).single()

    if (!pharmacy) {
      return NextResponse.json({ error: "Pharmacy not found" }, { status: 404 })
    }

    // Define pricing
    const prices: { [key: string]: { amount: number; name: string } } = {
      basic: { amount: 2999, name: "Basic Plan - $29.99/month" },
      pro: { amount: 7999, name: "Pro Plan - $79.99/month" },
      enterprise: { amount: 19999, name: "Enterprise Plan - $199.99/month" },
    }

    const selectedPrice = prices[plan] || prices.basic

    // Create or get Stripe customer
    let customerId = pharmacy.stripe_customer_id

    if (!customerId) {
      const customer = await stripe.customers.create({
        email: pharmacy.email,
        name: pharmacy.name,
        metadata: {
          pharmacy_id: userData.pharmacy_id,
        },
      })
      customerId = customer.id

      // Update pharmacy with Stripe customer ID
      await supabase.from("pharmacies").update({ stripe_customer_id: customerId }).eq("id", userData.pharmacy_id)
    }

    // Create checkout session
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ["card"],
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: selectedPrice.name,
              description: `PharmaCare ${plan.charAt(0).toUpperCase() + plan.slice(1)} Plan`,
            },
            unit_amount: selectedPrice.amount,
            recurring: {
              interval: "month",
            },
          },
          quantity: 1,
        },
      ],
      mode: "subscription",
      success_url: `${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/dashboard/billing?success=true`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/dashboard/billing?canceled=true`,
      metadata: {
        pharmacy_id: userData.pharmacy_id,
        plan,
      },
    })

    return NextResponse.json({ sessionId: session.id })
  } catch (error) {
    console.error("Checkout error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
