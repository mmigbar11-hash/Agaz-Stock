import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"
import Stripe from "stripe"

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", {
  apiVersion: "2024-11-20",
})

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET || ""

export async function POST(request: NextRequest) {
  const body = await request.text()
  const signature = request.headers.get("stripe-signature") || ""

  let event: Stripe.Event

  try {
    event = stripe.webhooks.constructEvent(body, signature, webhookSecret)
  } catch (error) {
    console.error("Webhook signature verification failed:", error)
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 })
  }

  const supabase = await createClient()

  try {
    switch (event.type) {
      case "customer.subscription.created":
      case "customer.subscription.updated": {
        const subscription = event.data.object as Stripe.Subscription
        const pharmacyId = subscription.metadata?.pharmacy_id

        if (pharmacyId) {
          const plan = subscription.metadata?.plan || "basic"
          await supabase
            .from("pharmacies")
            .update({
              subscription_status: "active",
              subscription_plan: plan,
            })
            .eq("id", pharmacyId)
        }
        break
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription
        const pharmacyId = subscription.metadata?.pharmacy_id

        if (pharmacyId) {
          await supabase
            .from("pharmacies")
            .update({
              subscription_status: "inactive",
              subscription_plan: "basic",
            })
            .eq("id", pharmacyId)
        }
        break
      }

      case "invoice.payment_succeeded": {
        const invoice = event.data.object as Stripe.Invoice
        const customerId = invoice.customer as string

        if (customerId) {
          const customer = await stripe.customers.retrieve(customerId)
          const pharmacyId = (customer as any).metadata?.pharmacy_id

          if (pharmacyId) {
            await supabase.from("pharmacies").update({ subscription_status: "active" }).eq("id", pharmacyId)
          }
        }
        break
      }

      case "invoice.payment_failed": {
        const invoice = event.data.object as Stripe.Invoice
        const customerId = invoice.customer as string

        if (customerId) {
          const customer = await stripe.customers.retrieve(customerId)
          const pharmacyId = (customer as any).metadata?.pharmacy_id

          if (pharmacyId) {
            await supabase.from("pharmacies").update({ subscription_status: "inactive" }).eq("id", pharmacyId)
          }
        }
        break
      }
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error("Webhook processing error:", error)
    return NextResponse.json({ error: "Webhook processing failed" }, { status: 500 })
  }
}
