import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

const TELEGRAM_API_URL = "https://api.telegram.org/bot"
const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN

async function sendTelegramMessage(chatId: number, text: string, parseMode = "HTML") {
  const response = await fetch(`${TELEGRAM_API_URL}${BOT_TOKEN}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: chatId,
      text,
      parse_mode: parseMode,
    }),
  })
  return response.json()
}

async function handleStockQuery(supabase: any, pharmacyId: string, chatId: number) {
  const { data: lowStockItems } = await supabase
    .from("stock")
    .select("id, quantity_available, low_stock_threshold_fixed, low_stock_threshold_percentage, products(name)")
    .eq("pharmacy_id", pharmacyId)

  if (!lowStockItems || lowStockItems.length === 0) {
    await sendTelegramMessage(chatId, "No low stock items found.")
    return
  }

  const filtered = lowStockItems.filter((item: any) => {
    const threshold = item.low_stock_threshold_fixed || Math.ceil((item.low_stock_threshold_percentage / 100) * 100)
    return item.quantity_available <= threshold
  })

  if (filtered.length === 0) {
    await sendTelegramMessage(chatId, "All items are in stock!")
    return
  }

  let message = "<b>Low Stock Items:</b>\n\n"
  filtered.slice(0, 10).forEach((item: any) => {
    message += `<b>${item.products.name}</b>\nQuantity: ${item.quantity_available}\n\n`
  })

  await sendTelegramMessage(chatId, message)
}

async function handleSalesQuery(supabase: any, pharmacyId: string, chatId: number, period = "today") {
  const now = new Date()
  const startDate = new Date()

  if (period === "today") {
    startDate.setHours(0, 0, 0, 0)
  } else if (period === "week") {
    startDate.setDate(now.getDate() - 7)
  } else if (period === "month") {
    startDate.setDate(now.getDate() - 30)
  }

  const { data: sales } = await supabase
    .from("sales")
    .select("total_amount")
    .eq("pharmacy_id", pharmacyId)
    .gte("created_at", startDate.toISOString())

  const totalRevenue = sales?.reduce((sum: number, sale: any) => sum + sale.total_amount, 0) || 0

  const message = `<b>Sales Report (${period.toUpperCase()})</b>\n\nTotal Revenue: $${totalRevenue.toFixed(2)}\nTransactions: ${sales?.length || 0}`

  await sendTelegramMessage(chatId, message)
}

async function handleTopProducts(supabase: any, pharmacyId: string, chatId: number) {
  const { data: sales } = await supabase
    .from("sales")
    .select("*, sales_items(*, products(name))")
    .eq("pharmacy_id", pharmacyId)
    .gte("created_at", new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString())

  if (!sales || sales.length === 0) {
    await sendTelegramMessage(chatId, "No sales data available.")
    return
  }

  const topProducts = sales
    .flatMap((s: any) => s.sales_items)
    .reduce((acc: any, item: any) => {
      const existing = acc.find((p: any) => p.name === item.products.name)
      if (existing) {
        existing.quantity += item.quantity
      } else {
        acc.push({
          name: item.products.name,
          quantity: item.quantity,
        })
      }
      return acc
    }, [])
    .sort((a: any, b: any) => b.quantity - a.quantity)
    .slice(0, 5)

  let message = "<b>Top Selling Products (Last 30 Days)</b>\n\n"
  topProducts.forEach((product: any, index: number) => {
    message += `${index + 1}. <b>${product.name}</b> - ${product.quantity} units\n`
  })

  await sendTelegramMessage(chatId, message)
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const message = body.message

    if (!message) {
      return NextResponse.json({ ok: true })
    }

    const chatId = message.chat.id
    const text = message.text || ""
    const telegramUserId = message.from.id

    const supabase = await createClient()

    // Find pharmacy by telegram user
    const { data: telegramUser } = await supabase
      .from("telegram_users")
      .select("pharmacy_id, user_id")
      .eq("telegram_user_id", telegramUserId)
      .single()

    if (!telegramUser) {
      await sendTelegramMessage(chatId, "Please register first. Use /register to link your account.")
      return NextResponse.json({ ok: true })
    }

    const pharmacyId = telegramUser.pharmacy_id

    // Handle commands
    if (text.startsWith("/start")) {
      const welcomeMessage = `Welcome to PharmaCare Bot! 🏥\n\nAvailable commands:\n/stock - Check low stock items\n/sales_today - Today's sales\n/sales_week - Weekly sales\n/sales_month - Monthly sales\n/top_products - Top selling products\n/help - Show help`
      await sendTelegramMessage(chatId, welcomeMessage)
    } else if (text.startsWith("/stock")) {
      await handleStockQuery(supabase, pharmacyId, chatId)
    } else if (text.startsWith("/sales_today")) {
      await handleSalesQuery(supabase, pharmacyId, chatId, "today")
    } else if (text.startsWith("/sales_week")) {
      await handleSalesQuery(supabase, pharmacyId, chatId, "week")
    } else if (text.startsWith("/sales_month")) {
      await handleSalesQuery(supabase, pharmacyId, chatId, "month")
    } else if (text.startsWith("/top_products")) {
      await handleTopProducts(supabase, pharmacyId, chatId)
    } else if (text.startsWith("/help")) {
      const helpMessage = `<b>PharmaCare Bot Commands</b>\n\n/stock - View low stock items\n/sales_today - Today's sales report\n/sales_week - Weekly sales report\n/sales_month - Monthly sales report\n/top_products - Top 5 selling products\n/help - Show this message`
      await sendTelegramMessage(chatId, helpMessage)
    } else {
      await sendTelegramMessage(chatId, "I didn't understand that command. Use /help to see available commands.")
    }

    return NextResponse.json({ ok: true })
  } catch (error) {
    console.error("Telegram webhook error:", error)
    return NextResponse.json({ ok: false, error: "Internal server error" }, { status: 500 })
  }
}
