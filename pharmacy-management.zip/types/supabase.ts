export type Database = {
  public: {
    Tables: {
      pharmacies: {
        Row: {
          id: string
          name: string
          email: string
          phone: string | null
          address: string | null
          city: string | null
          country: string | null
          subscription_status: string
          subscription_plan: string
          stripe_customer_id: string | null
          created_at: string
          updated_at: string
        }
      }
      users: {
        Row: {
          id: string
          pharmacy_id: string
          email: string
          full_name: string
          role: string
          is_active: boolean
          created_at: string
          updated_at: string
        }
      }
      products: {
        Row: {
          id: string
          pharmacy_id: string
          name: string
          sku: string
          barcode: string | null
          description: string | null
          category: string | null
          unit_price: number
          cost_price: number | null
          is_active: boolean
          created_at: string
          updated_at: string
        }
      }
      stock: {
        Row: {
          id: string
          pharmacy_id: string
          product_id: string
          quantity_available: number
          quantity_reserved: number
          low_stock_threshold_fixed: number | null
          low_stock_threshold_percentage: number
          last_restocked: string | null
          created_at: string
          updated_at: string
        }
      }
      sales: {
        Row: {
          id: string
          pharmacy_id: string
          user_id: string | null
          total_amount: number
          payment_method: string | null
          sale_source: string
          notes: string | null
          created_at: string
          updated_at: string
        }
      }
      sales_items: {
        Row: {
          id: string
          sale_id: string
          product_id: string
          quantity: number
          unit_price: number
          total_price: number
          created_at: string
        }
      }
      telegram_users: {
        Row: {
          id: string
          pharmacy_id: string
          user_id: string | null
          telegram_user_id: number
          telegram_username: string | null
          telegram_first_name: string | null
          is_active: boolean
          created_at: string
          updated_at: string
        }
      }
      stock_history: {
        Row: {
          id: string
          pharmacy_id: string
          product_id: string
          change_type: string
          quantity_change: number
          previous_quantity: number | null
          new_quantity: number | null
          notes: string | null
          created_by: string | null
          created_at: string
        }
      }
    }
  }
}
