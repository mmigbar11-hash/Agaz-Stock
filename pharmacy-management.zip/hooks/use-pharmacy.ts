"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import type { Database } from "@/types/supabase"

type Pharmacy = Database["public"]["Tables"]["pharmacies"]["Row"]

export function usePharmacy() {
  const [pharmacy, setPharmacy] = useState<Pharmacy | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const supabase = createClient()

    const getPharmacy = async () => {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser()
        if (!user) throw new Error("Not authenticated")

        // Get user's pharmacy from the users table
        const { data: userData, error: userError } = await supabase
          .from("users")
          .select("pharmacy_id")
          .eq("id", user.id)
          .single()

        if (userError) throw userError

        // Get pharmacy details
        const { data: pharmacyData, error: pharmacyError } = await supabase
          .from("pharmacies")
          .select("*")
          .eq("id", userData.pharmacy_id)
          .single()

        if (pharmacyError) throw pharmacyError
        setPharmacy(pharmacyData)
      } catch (err) {
        setError(err instanceof Error ? err.message : "An error occurred")
      } finally {
        setLoading(false)
      }
    }

    getPharmacy()
  }, [])

  return { pharmacy, loading, error }
}
