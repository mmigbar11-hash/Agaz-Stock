import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Package, AlertTriangle, DollarSign, ShoppingCart } from "lucide-react"

interface DashboardMetricsProps {
  totalProducts: number
  lowStockCount: number
  todayRevenue: number
  totalSales: number
}

export function DashboardMetrics({ totalProducts, lowStockCount, todayRevenue, totalSales }: DashboardMetricsProps) {
  const metrics = [
    {
      title: "Total Products",
      value: totalProducts,
      icon: Package,
      color: "bg-blue-500/10 text-blue-500",
    },
    {
      title: "Low Stock Items",
      value: lowStockCount,
      icon: AlertTriangle,
      color: "bg-orange-500/10 text-orange-500",
    },
    {
      title: "Today's Revenue",
      value: `$${todayRevenue.toFixed(2)}`,
      icon: DollarSign,
      color: "bg-green-500/10 text-green-500",
    },
    {
      title: "Today's Sales",
      value: totalSales,
      icon: ShoppingCart,
      color: "bg-purple-500/10 text-purple-500",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {metrics.map((metric) => {
        const Icon = metric.icon
        return (
          <Card key={metric.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{metric.title}</CardTitle>
              <div className={`p-2 rounded-lg ${metric.color}`}>
                <Icon className="w-4 h-4" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{metric.value}</div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
