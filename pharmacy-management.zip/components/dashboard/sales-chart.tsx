"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

interface SalesData {
  date: string
  revenue: number
}

export function SalesChart({ pharmacyId }: { pharmacyId: string }) {
  const [data, setData] = useState<SalesData[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchSalesData = async () => {
      const supabase = createClient()
      const { data: sales } = await supabase
        .from("sales")
        .select("total_amount, created_at")
        .eq("pharmacy_id", pharmacyId)
        .gte("created_at", new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString())

      if (sales) {
        const grouped: { [key: string]: number } = {}
        sales.forEach((sale: any) => {
          const date = new Date(sale.created_at).toLocaleDateString()
          grouped[date] = (grouped[date] || 0) + sale.total_amount
        })

        const chartData = Object.entries(grouped)
          .map(([date, revenue]) => ({ date, revenue }))
          .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())

        setData(chartData)
      }
      setLoading(false)
    }

    fetchSalesData()
  }, [pharmacyId])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Sales Trend (Last 30 Days)</CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <p className="text-sm text-muted-foreground">Loading...</p>
        ) : (
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="date" stroke="var(--muted-foreground)" />
              <YAxis stroke="var(--muted-foreground)" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "var(--card)",
                  border: "1px solid var(--border)",
                  borderRadius: "8px",
                }}
              />
              <Line type="monotone" dataKey="revenue" stroke="var(--primary)" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        )}
      </CardContent>
    </Card>
  )
}
