"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertTriangle } from "lucide-react"

interface LowStockItem {
  id: string
  product_id: string
  quantity_available: number
  products: {
    name: string
  }
}

export function LowStockAlerts({ pharmacyId }: { pharmacyId: string }) {
  const [lowStockItems, setLowStockItems] = useState<LowStockItem[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchLowStockItems = async () => {
      const supabase = createClient()
      const { data } = await supabase
        .from("stock")
        .select(
          "id, product_id, quantity_available, low_stock_threshold_fixed, low_stock_threshold_percentage, products(name)",
        )
        .eq("pharmacy_id", pharmacyId)

      if (data) {
        const filtered = data.filter((item: any) => {
          const threshold =
            item.low_stock_threshold_fixed || Math.ceil((item.low_stock_threshold_percentage / 100) * 100)
          return item.quantity_available <= threshold
        })
        setLowStockItems(filtered)
      }
      setLoading(false)
    }

    fetchLowStockItems()
  }, [pharmacyId])

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-orange-500" />
          Low Stock Alerts
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <p className="text-sm text-muted-foreground">Loading...</p>
        ) : lowStockItems.length === 0 ? (
          <p className="text-sm text-muted-foreground">No low stock items</p>
        ) : (
          <div className="space-y-3">
            {lowStockItems.slice(0, 5).map((item: any) => (
              <div key={item.id} className="flex items-center justify-between p-2 bg-muted rounded-lg">
                <div>
                  <p className="text-sm font-medium">{item.products?.name}</p>
                  <p className="text-xs text-muted-foreground">{item.quantity_available} units left</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
