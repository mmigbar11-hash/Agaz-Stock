"use client"

import { usePharmacy } from "@/hooks/use-pharmacy"
import type { User } from "@supabase/supabase-js"

export function Header({ user }: { user: User }) {
  const { pharmacy } = usePharmacy()

  return (
    <div className="bg-card border-b border-border px-8 py-4 flex items-center justify-between">
      <div>
        <h2 className="text-lg font-semibold text-foreground">{pharmacy?.name || "Pharmacy"}</h2>
        <p className="text-sm text-muted-foreground">{user.email}</p>
      </div>
      <div className="flex items-center gap-4">
        <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold">
          {user.email?.[0].toUpperCase()}
        </div>
      </div>
    </div>
  )
}
