import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface RecentSalesProps {
  sales: any[]
}

export function RecentSales({ sales }: RecentSalesProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Sales</CardTitle>
      </CardHeader>
      <CardContent>
        {sales.length === 0 ? (
          <p className="text-sm text-muted-foreground">No sales yet</p>
        ) : (
          <div className="space-y-4">
            {sales.map((sale: any) => (
              <div key={sale.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <div>
                  <p className="text-sm font-medium">
                    {sale.sales_items?.length || 0} item{sale.sales_items?.length !== 1 ? "s" : ""}
                  </p>
                  <p className="text-xs text-muted-foreground">{new Date(sale.created_at).toLocaleString()}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold">${sale.total_amount.toFixed(2)}</p>
                  <p className="text-xs text-muted-foreground capitalize">{sale.payment_method || "N/A"}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
